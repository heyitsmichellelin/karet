import React from 'react';

import './Main.css';
import Recipe from '../../components/Recipe/Recipe';

const MainPage = () => {
    return (
        <Recipe/>
    );
};

export default MainPage;

